# Repositorio-Trabalho

- As páginas devem conter 2 blocos conforme
  exemplo do próximo slide:
- Um bloco contendo os botões de navegação
- Outro bloco contendo o conteúdo da
  respectiva página

O projeto deve conter:

- Sobre
  • Nome
  • Endereço
  • E-mail (link para e-mail)
  • Descrição
  • Redes Sociais (Ícones com os Links)
- Conhecimentos (lista ordenada por letras)
- Objetivo: Pessoais e Profissionais (lista não-ordenada)
